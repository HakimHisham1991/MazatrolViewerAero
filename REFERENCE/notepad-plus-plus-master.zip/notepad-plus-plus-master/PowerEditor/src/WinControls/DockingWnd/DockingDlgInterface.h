// This file is part of Notepad++ project
// Copyright (C)2006 Jens Lorenz <jens.plugin.npp@gmx.de>

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// at your option any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.


#pragma once

#include <windows.h>

#include <shlwapi.h>

#include <array>
#include <cassert>
#include <string>

#include "Docking.h"
#include "Notepad_plus_msgs.h"
#include "NppDarkMode.h"
#include "StaticDialog.h"
#include "dockingResource.h"

class DockingDlgInterface : public StaticDialog
{
public:
	DockingDlgInterface() = default;
	explicit DockingDlgInterface(int dlgID): _dlgID(dlgID) {}

	void init(HINSTANCE hInst, HWND parent) override {
		StaticDialog::init(hInst, parent);
		wchar_t temp[MAX_PATH];
		::GetModuleFileName(hInst, temp, MAX_PATH);
		_moduleName = ::PathFindFileName(temp);
	}

	virtual void create(DockedWidgetData* data, bool isRTL = false) {
		assert(data != nullptr);
		StaticDialog::create(_dlgID, isRTL, false, 9, StaticDialog::getSystemFontFaceName());
		wchar_t temp[MAX_PATH];
		::GetWindowText(_hSelf, temp, MAX_PATH);
		_pluginName = temp;

		// user information
		data->hClient = _hSelf;
		data->pszName = _pluginName.c_str();

		// supported features by plugin
		data->uMask = 0;

		// additional info
		data->pszAddInfo = nullptr;
	}

	virtual void create(DockedWidgetData* data, std::array<int, 3> iconIDs, bool isRTL = false) {
		create(data, isRTL);
		_iconIDs = iconIDs;
	}

	virtual void updateDockingDlg() {
		::SendMessage(_hParent, NPPM_DMMUPDATEDISPINFO, 0, reinterpret_cast<LPARAM>(_hSelf));
	}

	virtual void setBackgroundColor(COLORREF) {}
	virtual void setForegroundColor(COLORREF) {}

	void display(bool toShow = true) const override {
		::SendMessage(_hParent, toShow ? NPPM_DMMSHOW : NPPM_DMMHIDE, 0, reinterpret_cast<LPARAM>(_hSelf));
	}

	bool isClosed() const {
		return _isClosed;
	}

	void setClosed(bool toClose) {
		_isClosed = toClose;
	}

	const wchar_t * getPluginFileName() const {
		return _moduleName.c_str();
	}

	const std::array<int, 3>& getIconIDs() const {
		return _iconIDs;
	}

	static void setFontForChild(HWND hChild, HFONT hFont) noexcept {
		if (hChild != nullptr)
		{
			::SendMessage(hChild, WM_SETFONT, reinterpret_cast<WPARAM>(hFont), MAKELPARAM(TRUE, 0));
		}
	}

	HFONT setFontForChild(HWND hChild) const noexcept {
		const auto hFont = reinterpret_cast<HFONT>(::SendMessage(_hSelf, WM_GETFONT, 0, 0));
		setFontForChild(hChild, hFont);
		return hFont;
	}

protected :
	int	_dlgID = -1;
	int _iDockedPos = 0;
	std::wstring _moduleName;
	std::wstring _pluginName;
	std::array<int, 3> _iconIDs{};
	bool _isFloating = true;
	bool _isClosed = false;

	using StaticDialog::create;

	virtual void onDpiChanged([[maybe_unused]] UINT prevDpi) {}

	intptr_t CALLBACK run_dlgProc(UINT message, WPARAM wParam, LPARAM lParam) override {
		switch (message)
		{
			case WM_ERASEBKGND:
			{
				if (!NppDarkMode::isEnabled())
				{
					break;
				}

				RECT rc{};
				getClientRect(rc);
				::FillRect(reinterpret_cast<HDC>(wParam), &rc, NppDarkMode::getDlgBackgroundBrush());
				return TRUE;
			}

			case WM_DPICHANGED:
			{
				const UINT prevDpi = _dpiManager.getDpi();
				_dpiManager.setDpiWP(wParam);
				onDpiChanged(prevDpi);
				return TRUE;
			}

			case WM_NOTIFY:
			{
				auto* pnmh = reinterpret_cast<LPNMHDR>(lParam);

				if (pnmh->hwndFrom == _hParent)
				{
					switch (LOWORD(pnmh->code))
					{
						case DMN_CLOSE:
						{
							break;
						}
						case DMN_FLOAT:
						{
							_isFloating = true;
							break;
						}
						case DMN_DOCK:
						{
							_iDockedPos = HIWORD(pnmh->code);
							_isFloating = false;
							break;
						}
						default:
							break;
					}
				}
				break;
			}
			default:
				break;
		}
		return FALSE;
	}
};
